import { useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { useSiteReveal } from '../../contexts/SiteRevealContext';

interface Point3D {
  x: number;
  y: number;
  z: number;
}

interface Particle3D {
  x: number;
  y: number;
  z: number;
  targets: Point3D[];
  color: string;
  size: number;
  speed: number;
  phase: number;
  pulseOffset: number;
}

// Reduce particles — 80 desktop, 40 mobile
const isMobile = () => typeof window !== 'undefined' && window.matchMedia('(max-width: 768px)').matches;
const PARTICLE_COUNT = isMobile() ? 40 : 80;

const generateParticles = (count: number): Particle3D[] => {
  const particles: Particle3D[] = [];
  for (let i = 0; i < count; i++) {
    const isLeftLobe = Math.random() > 0.5;
    const lobeX = isLeftLobe ? -35 : 35;
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.acos((Math.random() * 2) - 1);
    const r = 35 + Math.random() * 22;
    const s0 = {
      x: lobeX + Math.sin(phi) * Math.cos(theta) * r * 0.75,
      y: Math.sin(phi) * Math.sin(theta) * r * 1.1,
      z: Math.cos(phi) * r * 0.75
    };

    const s1 = {
      x: (Math.random() - 0.5) * 320,
      y: (Math.random() - 0.5) * 220,
      z: (Math.random() - 0.5) * 120
    };

    const channel = Math.floor(Math.random() * 10) - 5;
    const isHorizontal = Math.random() > 0.5;
    const s2 = {
      x: isHorizontal ? (Math.random() - 0.5) * 440 : channel * 40,
      y: isHorizontal ? channel * 35 : (Math.random() - 0.5) * 340,
      z: (Math.random() - 0.5) * 30
    };

    const cols = 12;
    const colIdx = i % cols;
    const rowIdx = Math.floor(i / cols);
    const s3 = {
      x: (colIdx - cols / 2) * 36,
      y: 75 + Math.sin(colIdx * 0.6) * 8,
      z: (rowIdx - 5) * 42
    };

    const s4 = {
      x: (Math.random() - 0.5) * 340,
      y: -180 + Math.random() * 320,
      z: (Math.random() - 0.5) * 140
    };

    const tHelix = (i / count) * Math.PI * 10;
    const rHelix = 24 + Math.sin(tHelix * 0.5) * 6;
    const s5 = {
      x: Math.cos(tHelix) * rHelix,
      y: (i / count - 0.5) * 110,
      z: Math.sin(tHelix) * rHelix
    };

    particles.push({
      x: s0.x,
      y: s0.y,
      z: s0.z,
      targets: [s0, s1, s2, s3, s4, s5],
      color: isLeftLobe ? 'rgba(34, 211, 238, 0.45)' : 'rgba(99, 102, 241, 0.4)',
      size: Math.random() * 1.6 + 0.8,
      speed: 0.15 + Math.random() * 0.45,
      phase: Math.random() * Math.PI * 2,
      pulseOffset: Math.random()
    });
  }
  return particles;
};

export default function Brand3DBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Use refs instead of state to avoid React re-renders on scroll/mouse
  const scrollProgressRef = useRef(0);
  const mousePosRef = useRef({ x: 0, y: 0 });

  const { isRevealed, isCinematic } = useSiteReveal();
  const isRevealedRef = useRef(isRevealed);

  // Sync isRevealed value to ref to avoid recreating draw loop
  useEffect(() => {
    isRevealedRef.current = isRevealed;
  }, [isRevealed]);

  useEffect(() => {
    // Scroll tracking via ref — no setState, no re-render
    const handleScroll = () => {
      const docHeight = document.documentElement.scrollHeight - window.innerHeight;
      if (docHeight > 0) {
        scrollProgressRef.current = window.scrollY / docHeight;
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    // Mouse tracking via ref — no setState, no re-render
    const handleMouseMove = (e: MouseEvent) => {
      mousePosRef.current = {
        x: (e.clientX - window.innerWidth / 2) / (window.innerWidth / 2),
        y: (e.clientY - window.innerHeight / 2) / (window.innerHeight / 2),
      };
    };
    window.addEventListener('mousemove', handleMouseMove, { passive: true });
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  // Single draw loop — never re-created (no deps that change)
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;
    const particles = generateParticles(PARTICLE_COUNT);

    // Only show orbits on desktop
    const showOrbits = !isMobile();
    const orbits = [
      { radius: 100, speed: 0.0004, color: 'rgba(34, 211, 238, 0.15)', name: 'React' },
      { radius: 130, speed: -0.0003, color: 'rgba(99, 102, 241, 0.15)', name: 'Secure' },
      { radius: 160, speed: 0.0002, color: 'rgba(34, 211, 238, 0.12)', name: 'Fast' }
    ];

    const resize = () => {
      if (!canvas || !containerRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      // Cap DPR at 1.5 for performance
      const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
      ctx.scale(dpr, dpr);
    };

    window.addEventListener('resize', resize);
    resize();

    const draw = () => {
      // Pause drawing entirely if document is hidden or the site entrance is not yet revealed.
      // This saves CPU and GPU cycles during loading/reveal screen!
      if (document.hidden || !isRevealedRef.current) {
        animationId = requestAnimationFrame(draw);
        return;
      }

      const scrollProgress = scrollProgressRef.current;
      const mousePos = mousePosRef.current;
      const width = canvas.width / (window.devicePixelRatio || 1);
      const height = canvas.height / (window.devicePixelRatio || 1);

      ctx.clearRect(0, 0, width, height);

      const morphProgress = scrollProgress * 5;
      const stateIdx = Math.floor(morphProgress);
      const nextStateIdx = Math.min(stateIdx + 1, 5);
      const interpolation = morphProgress - stateIdx;

      const time = Date.now();
      const rotY = time * 0.00015 + mousePos.x * 0.12;
      const rotX = 0.2 + time * 0.00005 + mousePos.y * 0.08;

      const cosY = Math.cos(rotY);
      const sinY = Math.sin(rotY);
      const cosX = Math.cos(rotX);
      const sinX = Math.sin(rotX);

      const projectedPoints: { x: number; y: number; z: number; size: number; color: string }[] = [];

      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];
        const startVal = p.targets[stateIdx];
        const endVal = p.targets[nextStateIdx];

        let targetX = startVal.x + (endVal.x - startVal.x) * interpolation;
        let targetY = startVal.y + (endVal.y - startVal.y) * interpolation;
        let targetZ = startVal.z + (endVal.z - startVal.z) * interpolation;

        const waveTime = time * 0.0008 * p.speed + p.phase;
        targetX += Math.sin(waveTime) * 3;
        targetY += Math.cos(waveTime * 0.9) * 3;
        targetZ += Math.sin(waveTime * 1.1) * 3;

        p.x += (targetX - p.x) * 0.085;
        p.y += (targetY - p.y) * 0.085;
        p.z += (targetZ - p.z) * 0.085;

        const x1 = p.x * cosY - p.z * sinY;
        const z1 = p.x * sinY + p.z * cosY;
        const y2 = p.y * cosX - z1 * sinX;
        const z2 = p.y * sinX + z1 * cosX;

        const d = 360;
        const scaleVal = d / (d + z2);

        let centerX = width / 2;
        let centerY = height / 2;

        if (stateIdx === 0) {
          centerY -= 20 * (1 - interpolation);
        } else if (stateIdx === 4) {
          centerY += 10 * interpolation;
        }

        const screenX = centerX + x1 * scaleVal * 4.6;
        const screenY = centerY + y2 * scaleVal * 4.6;

        projectedPoints.push({
          x: screenX,
          y: screenY,
          z: z2,
          size: p.size * scaleVal,
          color: p.color
        });
      }

      // Connection lines — optimized: cap connections per node early, no Math.sqrt via dist² comparison
      ctx.lineWidth = 0.45;
      ctx.shadowBlur = 0; // No per-line glow for performance
      const maxDistance = stateIdx === 3 ? 55 : 46;
      const maxDistSq = maxDistance * maxDistance;

      for (let i = 0; i < projectedPoints.length; i++) {
        const p1 = projectedPoints[i];
        let connectionCount = 0;

        for (let j = i + 1; j < projectedPoints.length; j++) {
          if (connectionCount > 3) break;

          const p2 = projectedPoints[j];
          const dx = p1.x - p2.x;
          const dy = p1.y - p2.y;
          const distSq = dx * dx + dy * dy;

          if (distSq < maxDistSq) {
            connectionCount++;
            const dist = Math.sqrt(distSq);
            const alphaFactor = (1 - dist / maxDistance) * 0.09;
            ctx.beginPath();
            ctx.moveTo(p1.x, p1.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.strokeStyle = `rgba(34, 211, 238, ${alphaFactor})`;
            ctx.stroke();
          }
        }
      }

      // Orbit nodes — only in Hero state, only on desktop
      if (showOrbits && stateIdx === 0 && interpolation < 0.8) {
        const opacityHero = 1 - interpolation;

        orbits.forEach((orbit, oIdx) => {
          const orbitAngle = time * orbit.speed + oIdx * Math.PI * 0.6;
          const oX = Math.cos(orbitAngle) * orbit.radius;
          const oZ = Math.sin(orbitAngle) * orbit.radius * 0.4;
          const oY = Math.sin(orbitAngle * 0.8) * 15;

          const ox1 = oX * cosY - oZ * sinY;
          const oz1 = oX * sinY + oZ * cosY;
          const oy2 = oY * cosX - oz1 * sinX;
          const oz2 = oY * sinX + oz1 * cosX;

          const oScale = 360 / (360 + oz2);
          const osX = width / 2 + ox1 * oScale * 4.6;
          const osY = height / 2 - 20 + oy2 * oScale * 4.6;

          ctx.beginPath();
          ctx.ellipse(width / 2, height / 2 - 20, orbit.radius * 4.6, orbit.radius * 4.6 * 0.35, rotX, 0, Math.PI * 2);
          ctx.strokeStyle = `rgba(255, 255, 255, ${0.015 * opacityHero})`;
          ctx.lineWidth = 0.5;
          ctx.stroke();

          ctx.beginPath();
          ctx.arc(osX, osY, 3.5 * oScale, 0, Math.PI * 2);
          ctx.fillStyle = orbit.color;
          ctx.fill();

          ctx.beginPath();
          ctx.arc(osX, osY, 3.5 * oScale * 2.2, 0, Math.PI * 2);
          ctx.fillStyle = `rgba(34, 211, 238, ${0.05 * opacityHero})`;
          ctx.fill();

          ctx.font = '7px monospace';
          ctx.fillStyle = `rgba(255, 255, 255, ${0.25 * opacityHero})`;
          ctx.fillText(orbit.name, osX + 8, osY + 2);
        });
      }

      // Draw particles — no shadowBlur per particle
      for (let i = 0; i < projectedPoints.length; i++) {
        const p = projectedPoints[i];

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = p.color;
        ctx.fill();

        // Ambient glow ring — skip on mobile for performance
        if (!isMobile()) {
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size * 2.8, 0, Math.PI * 2);
          ctx.fillStyle = p.color.replace('0.4', '0.06').replace('0.3', '0.04');
          ctx.fill();
        }
      }

      animationId = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', resize);
    };
  }, []);

  return (
    <motion.div
      ref={containerRef}
      initial={{ opacity: 0 }}
      animate={{ opacity: isRevealed ? 0.28 : 0 }}
      transition={{
        duration: isCinematic ? 3.5 : 0.5,
        delay:    isCinematic ? 2.0 : 0.2,
        ease: 'easeOut',
      }}
      className="fixed inset-0 w-full h-full overflow-hidden pointer-events-none -z-30 bg-[#050505]"
    >
      <canvas ref={canvasRef} className="block w-full h-full" />
    </motion.div>
  );
}
