import { useState, useEffect, useRef } from 'react';
import { BrowserRouter } from 'react-router-dom';
import AppRoutes from './routes/AppRoutes';
import GatewayEntrance from './components/ui/LoadingScreen';
import WhatsAppModal from './components/ui/WhatsAppModal';
import { SiteRevealContext } from './contexts/SiteRevealContext';

const SESSION_KEY = 'lbi_gateway_entered';

function App() {
  const alreadyEntered = sessionStorage.getItem(SESSION_KEY) === 'true';

  const [showGateway, setShowGateway] = useState(!alreadyEntered);
  // If already entered, site is immediately revealed (no animation)
  const [siteRevealed, setSiteRevealed] = useState(alreadyEntered);
  const [isCinematic, setIsCinematic] = useState(false);
  const [gatewayStatus, setGatewayStatus] = useState<
    'idle' | 'reacting' | 'dissolving' | 'completed'
  >(alreadyEntered ? 'completed' : 'idle');
  const [isWhatsAppOpen, setIsWhatsAppOpen] = useState(false);
  const siteRef = useRef<HTMLDivElement>(null);
  // Track whether the blur/scale transition has finished so we can clean up willChange
  const [revealSettled, setRevealSettled] = useState(alreadyEntered);

  const startEntranceTransition = () => {
    if (gatewayStatus !== 'idle') return;

    // Mark cinematic mode FIRST so context is correct when children re-render
    setIsCinematic(true);
    // Immediately reveal the site — blur/scale CSS transition begins NOW
    setSiteRevealed(true);
    sessionStorage.setItem(SESSION_KEY, 'true');

    // Step 1 — sphere reacts (visual only in LoadingScreen)
    setGatewayStatus('reacting');

    // Step 2 — sphere dissolves, overlay background fades
    setTimeout(() => {
      setGatewayStatus('dissolving');
    }, 300);

    // Step 3 — blur+scale transition is done (~2.2s); clean up willChange
    setTimeout(() => {
      setRevealSettled(true);
    }, 2400);

    // Step 4 — remove gateway overlay entirely
    setTimeout(() => {
      setGatewayStatus('completed');
      setShowGateway(false);
    }, 3000);
  };

  // Keyboard shortcut: Enter / Space
  useEffect(() => {
    if (!showGateway || gatewayStatus !== 'idle') return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        startEntranceTransition();
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [showGateway, gatewayStatus]);

  useEffect(() => {
    const handleOpenModal = () => setIsWhatsAppOpen(true);
    window.addEventListener('open-whatsapp-modal', handleOpenModal);
    return () => window.removeEventListener('open-whatsapp-modal', handleOpenModal);
  }, []);

  // ── Site reveal styles ──────────────────────────────────────────────────────
  const siteStyle: React.CSSProperties = {
    opacity: siteRevealed ? 1 : 0,
    // Blur: eyes-focusing fog-lift effect on first reveal
    filter: siteRevealed ? 'blur(0px)' : 'blur(22px)',
    // Slight scale: visitor feels they're zooming into focus
    transform: siteRevealed ? 'scale(1)' : 'scale(1.03)',
    transition: [
      'opacity 1.8s cubic-bezier(0.25, 0.46, 0.45, 0.94)',
      'filter 2.2s cubic-bezier(0.25, 0.46, 0.45, 0.94)',
      'transform 2.2s cubic-bezier(0.25, 0.46, 0.45, 0.94)',
    ].join(', '),
    // Remove will-change once settled to free GPU memory
    willChange: revealSettled ? 'auto' : 'opacity, filter, transform',
    pointerEvents: siteRevealed ? 'auto' : 'none',
  };

  return (
    <>
      {/* ── Site – always mounted; blur/scale fades away on reveal ── */}
      <SiteRevealContext.Provider value={{ isRevealed: siteRevealed, isCinematic, isSettled: revealSettled }}>
        <div ref={siteRef} style={siteStyle}>
          <BrowserRouter>
            <AppRoutes />
          </BrowserRouter>
        </div>
      </SiteRevealContext.Provider>

      {/* ── Gateway overlay ─────────────────────────────────────────────── */}
      {showGateway && (
        <GatewayEntrance
          onEnter={startEntranceTransition}
          gatewayStatus={gatewayStatus}
        />
      )}

      <WhatsAppModal isOpen={isWhatsAppOpen} onClose={() => setIsWhatsAppOpen(false)} />
    </>
  );
}

export default App;
